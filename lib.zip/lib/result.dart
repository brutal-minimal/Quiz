import 'package:flutter/material.dart';

class Result extends StatelessWidget {
  final int resultScore;
  final VoidCallback resetHandler;
  String? resultPhrase;

  Result(this.resultScore, this.resetHandler);

  String? getresultPhrase(int resultScore) {
    String? resultText;
    if (resultScore<= 5){
      resultText = "youre stupid";
    } else if(resultScore <= 10){
      resultText ="youre dump";
    } else if(resultScore >= 15){
      resultText = "come here ill use you";
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Text (
            resultPhrase!,
            style: TextStyle(fontSize: 36),),
            TextButton(
              onPressed: resetHandler, 
              child: Text("again please"),
              ) 
        ],
      ));
  }
}