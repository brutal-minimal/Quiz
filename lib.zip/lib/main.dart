
//import 'dart:ffi';

import 'package:flutter/material.dart';

import "./quiz.dart";
import './result.dart';

void main() {
  runApp(MyWife());
}

class MyWife extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _MyWifeState();
  } 
}

class _MyWifeState extends State<MyWife> {
  
  final _questions = const [
    {
      "questionText": 'What\'s your less fav option?',
      "answers":  [
        {"text": "Introduce yourself by credit card password", "score": 8},
        {"text":"Pass by secret password", "score": 3},
        {"text":"Donate", "score": 5} 
        ]
    },
    {
      "questionText": 'Your main transversial competency',
      "answers":  [
        {"text":"Self-taught", "score": 9},
        {"text":"International acknowledgment", "score": 4},
        {"text":"People pleasing", "score": 1}, 
        {"text":"Interracial skills", "score": 2} 
        ]
    },
    {
      "questionText": 'Breakfast booster',
      "answers":  [
        {"text":"red bull energy drink", "score": 7}, 
        {"text":"caffeine pill", "score": 5},
        {"text":"champagne", "score": 4} 
        ]
    }
  ];
  var _questionIndex = 0;
  var _totalScore= 0;
  
  void _resetQuiz(){
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
      
    });
   
  }

   void _answerQuestion (int score){
    _totalScore += score;
    setState(() {
      _questionIndex = _questionIndex + 1;
    });
    print(_questionIndex);
      if (_questionIndex < _questions.length){
        print("good");
      }
      else {
        print("still good");
      };
      
    }
  

  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(
      title: ("People are just properties"),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 123, 53, 88),
        appBar: AppBar(
          title: Text("Reptilodio")
          ),
        body: _questionIndex < _questions.length 
            ? Quiz(
              answerQuestion: _answerQuestion,
              questionIndex: _questionIndex,
              questions: _questions
              )
              : Result(_totalScore, _resetQuiz)
        ),
      
      );
  }
}

